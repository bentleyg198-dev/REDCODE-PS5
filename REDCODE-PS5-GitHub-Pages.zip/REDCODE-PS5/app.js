(() => {
  const $ = (id) => document.getElementById(id);
  const pages = ["dashboard", "aim", "esp", "settings"];
  function showPage(name) {
    if (!pages.includes(name)) return;
    document.querySelectorAll(".page").forEach(p => p.classList.toggle("active", p.id === `page-${name}`));
    document.querySelectorAll(".nav-item").forEach(b => b.classList.toggle("active", b.dataset.page === name));
    $("sidebar").classList.remove("open");
    $("menuToggle").setAttribute("aria-expanded", "false");
    window.scrollTo({top: 0, behavior: "smooth"});
  }
  document.querySelectorAll("[data-page]").forEach(b => b.addEventListener("click", () => showPage(b.dataset.page)));
  document.querySelectorAll("[data-go]").forEach(b => b.addEventListener("click", () => showPage(b.dataset.go)));
  $("menuToggle").addEventListener("click", () => {
    const open = $("sidebar").classList.toggle("open");
    $("menuToggle").setAttribute("aria-expanded", String(open));
  });

  const fov = $("fov"), scale = $("scale"), reticle = $("reticle");
  function updateAim() {
    const size = Number(fov.value);
    $("fovValue").value = `${size}°`;
    $("fovReadout").textContent = `FOV ${size}°`;
    const diameter = 100 + (size - 30) * (130 / 150);
    reticle.style.width = `${diameter}px`;
    reticle.style.height = `${diameter}px`;
    const s = Number(scale.value);
    $("scaleValue").value = `${s}%`;
    reticle.style.setProperty("--reticle-scale", s / 100);
    reticle.style.transform = `translate(-50%,-50%) scale(${s / 100})`;
    reticle.classList.toggle("hidden", !$("reticleToggle").checked);
    reticle.classList.toggle("style-dot", $("reticleStyle").value === "dot");
    reticle.classList.toggle("style-circle", $("reticleStyle").value === "circle");
  }
  [fov, scale, $("reticleToggle"), $("reticleStyle")].forEach(el => el.addEventListener("input", updateAim));
  $("resetAim").addEventListener("click", () => {
    fov.value = 90; scale.value = 100; $("reticleToggle").checked = true; $("reticleStyle").value = "cross"; updateAim();
  });
  function updateEsp() {
    document.querySelectorAll(".fake-target").forEach(el => {
      el.classList.toggle("hide-box", !$("boxesToggle").checked);
      el.classList.toggle("hide-label", !$("labelsToggle").checked);
    });
  }
  [$("boxesToggle"), $("labelsToggle")].forEach(el => el.addEventListener("change", updateEsp));
  $("resetEsp").addEventListener("click", () => {
    $("boxesToggle").checked = true; $("labelsToggle").checked = true; updateEsp();
  });

  const accents = {
    red: ["#f12d43", "241,45,67"],
    blue: ["#319cff", "49,156,255"],
    purple: ["#a56bff", "165,107,255"]
  };
  function setAccent(name) {
    const pair = accents[name] || accents.red;
    document.documentElement.style.setProperty("--accent", pair[0]);
    document.documentElement.style.setProperty("--accent-rgb", pair[1]);
    document.querySelectorAll(".swatch").forEach(b => b.classList.toggle("selected", b.dataset.accent === name));
    try { localStorage.setItem("redcode-accent", name); } catch (_) {}
  }
  document.querySelectorAll(".swatch").forEach(b => b.addEventListener("click", () => setAccent(b.dataset.accent)));
  $("resetAll").addEventListener("click", () => {
    setAccent("red");
    $("resetAim").click(); $("resetEsp").click();
  });
  try {
    const saved = localStorage.getItem("redcode-accent");
    if (saved && accents[saved]) setAccent(saved);
  } catch (_) {}
  updateAim(); updateEsp();

  // Keep controller/keyboard navigation predictable and make focused controls visible.
  document.addEventListener("keydown", e => {
    if (e.key === "Escape") {
      $("sidebar").classList.remove("open");
      $("menuToggle").setAttribute("aria-expanded", "false");
    }
  });
})();
