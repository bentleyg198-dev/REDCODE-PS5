# REDCODE PS5

A responsive, controller-friendly static website with a fictional visual HUD simulator. It does not connect to Fortnite, track players, automate aiming, modify a console, or provide cheats.

## Preview locally
Open `index.html` in a modern browser.

## Publish with GitHub Pages
1. Create a new **public** GitHub repository named `REDCODE-PS5` (or any name you prefer).
2. Upload the contents of this folder to the repository root. Make sure `.github/workflows/pages.yml` is included.
3. In the repository, open **Settings → Pages**.
4. Under **Build and deployment → Source**, choose **GitHub Actions**.
5. Push to the `main` branch (or use **Actions → Deploy static site to GitHub Pages → Run workflow**).
6. Wait for the workflow to finish. Your site URL will appear in the workflow deployment summary and in **Settings → Pages**.

Typical URL for a repository named `REDCODE-PS5`:
`https://YOUR-GITHUB-USERNAME.github.io/REDCODE-PS5/`

## PS5 browser use
Open the published URL in the PS5 browser. Use the D-pad to move focus, and press the controller's confirm button to activate controls. Browser support and availability can vary by console firmware.

## Files
- `index.html` — page structure and interface
- `styles.css` — responsive black/crimson design
- `app.js` — navigation, HUD controls, preferences
- `assets/favicon.svg` — site icon
- `.github/workflows/pages.yml` — GitHub Pages deployment workflow
- `.nojekyll` — disables Jekyll processing
